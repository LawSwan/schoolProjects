<!DOCTYPE html>
<html>
<head>
    <title>Amber Lawson Wk 4</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #6c4a5dff;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .form-section {
            background-color: #f9f9f9;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: inline-block;
            width: 200px;
            font-weight: bold;
        }
        input[type="text"], input[type="date"] {
            width: 250px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"], button {
            background-color: #7b5f91ff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 5px;
        }
        input[type="submit"]:hover, button:hover {
            background-color: #6e2da0ff;
        }
        .delete-btn {
            background-color: #dc3545;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
        .edit-btn {
            background-color: #28a745;
        }
        .edit-btn:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #d581e5ff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Amber Lawson Week 4 Guided Practice</h1>
        
        <?php echo isset($message) ? $message : ''; ?>

        <!-- Form Section -->
        <div class="form-section">
            <h2><?php echo (isset($editId) && $editId > 0) ? "Update Personal Information" : "Add New Personal Information"; ?></h2>
            <form method="POST" action="?action=<?php echo (isset($editId) && $editId > 0) ? 'update' : 'add'; ?>">
                <?php if (isset($editId) && $editId > 0): ?>
                    <input type="hidden" name="id" value="<?php echo (int)$editId; ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" 
                           value="<?php echo isset($editData['name']) ? htmlspecialchars($editData['name']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="date_of_birth">Date of Birth:</label>
                    <input type="date" id="date_of_birth" name="date_of_birth" 
                           value="<?php echo isset($editData['date_of_birth']) ? htmlspecialchars($editData['date_of_birth']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="favorite_color">Favorite Color:</label>
                    <input type="text" id="favorite_color" name="favorite_color" 
                           value="<?php echo isset($editData['favorite_color']) ? htmlspecialchars($editData['favorite_color']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="favorite_place">Favorite Place To Visit:</label>
                    <input type="text" id="favorite_place" name="favorite_place" 
                           value="<?php echo isset($editData['favorite_place']) ? htmlspecialchars($editData['favorite_place']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="nickname">Nickname:</label>
                    <input type="text" id="nickname" name="nickname" 
                           value="<?php echo isset($editData['nickname']) ? htmlspecialchars($editData['nickname']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <?php if (isset($editId) && $editId > 0): ?>
                        <input type="submit" value="Update Information">
                        <a href="?">
                            <button type="button">Cancel Edit</button>
                        </a>
                    <?php else: ?>
                        <input type="submit" value="Add Information">
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Display Records -->
        <div class="form-section">
            <h2>Personal Information Database Contents</h2>
            
            <?php if (isset($records) && is_array($records) && count($records) > 0) { ?>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Favorite Color</th>
                        <th>Favorite Place</th>
                        <th>Nickname</th>
                        <th>Actions</th>
                    </tr>
                    <?php foreach ($records as $row) { ?>
                        <tr>
                            <td><?php echo (int)$row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_of_birth']); ?></td>
                            <td><?php echo htmlspecialchars($row['favorite_color']); ?></td>
                            <td><?php echo htmlspecialchars($row['favorite_place']); ?></td>
                            <td><?php echo htmlspecialchars($row['nickname']); ?></td>
                            <td>
                                <a href="?action=edit&id=<?php echo (int)$row['id']; ?>">
                                    <button class="edit-btn">Edit</button>
                                </a>
                                <a href="?action=delete&id=<?php echo (int)$row['id']; ?>" 
                                   onclick="return confirm('Are you sure you want to delete this record?')">
                                    <button class="delete-btn">Delete</button>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            <?php } else { ?>
                <p>No records found in the database.</p>
            <?php } ?>
        </div>
    </div>
</body>
</html>
