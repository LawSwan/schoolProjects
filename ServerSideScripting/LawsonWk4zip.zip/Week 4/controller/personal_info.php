<?php
require_once __DIR__ . '/../model/db_connection.php';
require_once __DIR__ . '/../model/PersonalInfoModel.php';

$message = '';
$editId = 0;
$editData = array();

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payload = array(
        'name' => isset($_POST['name']) ? $_POST['name'] : '',
        'date_of_birth' => isset($_POST['date_of_birth']) ? $_POST['date_of_birth'] : '',
        'favorite_color' => isset($_POST['favorite_color']) ? $_POST['favorite_color'] : '',
        'favorite_place' => isset($_POST['favorite_place']) ? $_POST['favorite_place'] : '',
        'nickname' => isset($_POST['nickname']) ? $_POST['nickname'] : ''
    );

    if ($action === 'add') {
        $message = pi_create($conn, $payload)
            ? "<div class='message success'>New record added successfully!</div>"
            : "<div class='message error'>Operation failed.</div>";
    } elseif ($action === 'update') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $message = pi_update($conn, $id, $payload)
            ? "<div class='message success'>Record updated successfully!</div>"
            : "<div class='message error'>Operation failed.</div>";
    }
}

if ($action === 'delete') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $message = pi_delete($conn, $id)
        ? "<div class='message success'>Record deleted successfully!</div>"
        : "<div class='message error'>Delete failed.</div>";
}

if ($action === 'edit') {
    $editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $editData = pi_get_by_id($conn, $editId);
    if (!$editData) {
        $editId = 0;
        $editData = array();
    }
}

$records = pi_get_all($conn);

require __DIR__ . '/../View/Lawson_wk3pa.php';

