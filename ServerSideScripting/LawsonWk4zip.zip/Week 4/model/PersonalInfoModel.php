<?php
require_once __DIR__ . '/db_connection.php';

function pi_get_all($conn) {
    $result = mysqli_query($conn, "SELECT * FROM personal_info ORDER BY id DESC");
    if (!$result) {
        return array();
    }
    $rows = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function pi_get_by_id($conn, $id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM personal_info WHERE id = ?");
    if (!$stmt) {
        return null;
    }
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if (!$res) {
        return null;
    }
    return mysqli_fetch_assoc($res) ?: null;
}

function pi_create($conn, $data) {
    $stmt = mysqli_prepare($conn, "INSERT INTO personal_info (name, date_of_birth, favorite_color, favorite_place, nickname) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        return false;
    }
    $name = $data['name'] ?? '';
    $dob = $data['date_of_birth'] ?? '';
    $color = $data['favorite_color'] ?? '';
    $place = $data['favorite_place'] ?? '';
    $nickname = $data['nickname'] ?? '';
    mysqli_stmt_bind_param($stmt, "sssss", $name, $dob, $color, $place, $nickname);
    return mysqli_stmt_execute($stmt) === true;
}

function pi_update($conn, $id, $data) {
    $stmt = mysqli_prepare($conn, "UPDATE personal_info SET name = ?, date_of_birth = ?, favorite_color = ?, favorite_place = ?, nickname = ? WHERE id = ?");
    if (!$stmt) {
        return false;
    }
    $name = $data['name'] ?? '';
    $dob = $data['date_of_birth'] ?? '';
    $color = $data['favorite_color'] ?? '';
    $place = $data['favorite_place'] ?? '';
    $nickname = $data['nickname'] ?? '';
    mysqli_stmt_bind_param($stmt, "sssssi", $name, $dob, $color, $place, $nickname, $id);
    return mysqli_stmt_execute($stmt) === true;
}

function pi_delete($conn, $id) {
    $stmt = mysqli_prepare($conn, "DELETE FROM personal_info WHERE id = ?");
    if (!$stmt) {
        return false;
    }
    mysqli_stmt_bind_param($stmt, "i", $id);
    return mysqli_stmt_execute($stmt) === true;
}


